package com.example.optionmenu_contextmenu

class Student (var name: String, var mssv: String)